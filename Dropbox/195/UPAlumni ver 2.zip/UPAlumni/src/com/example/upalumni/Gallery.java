package com.example.upalumni;

import android.app.Activity;
import android.os.Bundle;

public class Gallery extends Activity{
	protected void onCreate(Bundle savedInstanceState) 
	{
	    super.onCreate(savedInstanceState);
	    setContentView (R.layout.activity_gallery);
	}

}
